from input_module import  userinput
from output_module import useroutput
from process_module import userprocess

num1, num2 = userinput()
sum = num1 + num2
difference = num1 - num2
product = num1 * num2
quotient = num1 / num2
useroutput(sum, difference, product, quotient)
