def useroutput(sum, difference, product, quotient):
    print("sum:" , sum)
    print("Difference:" + str(difference))
    print("product:" + str(product))
    print("Quotient:" + str(quotient))